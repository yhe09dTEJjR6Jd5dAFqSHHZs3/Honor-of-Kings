import os
import sys
import time
import math
import queue
import sqlite3
import random
import shutil
import struct
import ctypes
import threading
import subprocess
import traceback
from pathlib import Path
from ctypes import wintypes
import tkinter as tk
from tkinter import filedialog, messagebox

APP = "Honor of Kings AI"
DEFAULT_HOME = r"D:\HonorofKings"
DEFAULT_PLAYER = r"E:\LDPlayer\dnplayer.exe"
PACKAGE = "com.tencent.tmgp.sgame"
MAGIC = 0x484F4B41494D4F44
MIN_SAMPLES = 160
MAX_SAMPLES = 30000
FRAME_W = 96
FRAME_H = 54
FRAME_STACK = 4
TYPE_IDLE = 0
TYPE_KEY_DOWN = 1
TYPE_KEY_UP = 2
TYPE_MOUSE_DOWN_L = 3
TYPE_MOUSE_UP_L = 4
TYPE_MOUSE_DOWN_R = 5
TYPE_MOUSE_UP_R = 6
TYPE_MOUSE_MOVE = 7
TYPE_COUNT = 8

if os.name != "nt" or struct.calcsize("P") != 8:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(APP, "仅支持 Windows 11 x64。")
    raise SystemExit(1)

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14
HC_ACTION = 0
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
LLKHF_INJECTED = 0x10
LLMHF_INJECTED = 0x01
GA_ROOT = 2
SW_RESTORE = 9
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_VIRTUALDESK = 0x4000
SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79

ULONG_PTR = ctypes.c_size_t
LRESULT = ctypes.c_ssize_t

class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

LowLevelProc = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

user32.SetWindowsHookExW.argtypes = [ctypes.c_int, LowLevelProc, wintypes.HINSTANCE, wintypes.DWORD]
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
user32.CallNextHookEx.restype = LRESULT
user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
user32.UnhookWindowsHookEx.restype = wintypes.BOOL
user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
user32.SendInput.restype = wintypes.UINT


def norm_path(p):
    return os.path.abspath(os.path.expandvars(os.path.expanduser(p.strip().strip('"'))))


def drive_of(p):
    return os.path.splitdrive(norm_path(p))[0].upper()


def ensure_non_system_folder(p):
    p = norm_path(p)
    d = drive_of(p)
    system_drive = os.environ.get("SystemDrive", "C:").upper()
    if not d or d == system_drive:
        raise RuntimeError("运行目录必须位于非系统盘。")
    if not os.path.exists(d + "\\"):
        raise RuntimeError("所选磁盘不存在。")
    os.makedirs(p, exist_ok=True)
    test = os.path.join(p, ".write_test")
    with open(test, "wb") as f:
        f.write(b"1")
    os.remove(test)
    return p


def configure_storage(home):
    runtime = os.path.join(home, ".honorofkings")
    paths = {
        "runtime": runtime,
        "site": os.path.join(runtime, "site-packages"),
        "tmp": os.path.join(runtime, "tmp"),
        "cache": os.path.join(runtime, "cache"),
        "torch": os.path.join(runtime, "torch"),
        "data": os.path.join(runtime, "data"),
        "models": os.path.join(runtime, "models"),
        "logs": os.path.join(runtime, "logs"),
        "pycache": os.path.join(runtime, "pycache"),
    }
    for p in paths.values():
        os.makedirs(p, exist_ok=True)
    os.environ["TMP"] = paths["tmp"]
    os.environ["TEMP"] = paths["tmp"]
    os.environ["TMPDIR"] = paths["tmp"]
    os.environ["PIP_CACHE_DIR"] = paths["cache"]
    os.environ["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    os.environ["PYTHONNOUSERSITE"] = "1"
    os.environ["TORCH_HOME"] = paths["torch"]
    os.environ["XDG_CACHE_HOME"] = paths["cache"]
    os.environ["HF_HOME"] = os.path.join(paths["cache"], "huggingface")
    os.environ["CUDA_CACHE_PATH"] = os.path.join(paths["cache"], "cuda")
    os.environ["TORCHINDUCTOR_CACHE_DIR"] = os.path.join(paths["cache"], "torchinductor")
    os.environ["TRITON_CACHE_DIR"] = os.path.join(paths["cache"], "triton")
    for extra in (os.environ["HF_HOME"], os.environ["CUDA_CACHE_PATH"], os.environ["TORCHINDUCTOR_CACHE_DIR"], os.environ["TRITON_CACHE_DIR"]):
        os.makedirs(extra, exist_ok=True)
    try:
        sys.pycache_prefix = paths["pycache"]
    except Exception:
        pass
    if paths["site"] not in sys.path:
        sys.path.insert(0, paths["site"])
    return paths


def run_pip(site, args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--upgrade", "--target", site] + list(args)
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=creationflags, env=os.environ.copy())
    if p.returncode != 0:
        raise RuntimeError("依赖安装失败：\n" + p.stdout[-5000:])


def ensure_dependencies(paths, status):
    site = paths["site"]
    status("检查本地 AI 运行环境…")
    local_numpy = os.path.isdir(os.path.join(site, "numpy"))
    local_mss = os.path.isdir(os.path.join(site, "mss"))
    if not (local_numpy and local_mss):
        status("正在把基础依赖安装到所选目录…")
        run_pip(site, ["numpy>=1.26,<3", "mss>=10,<11"])
    local_torch = os.path.isdir(os.path.join(site, "torch"))
    try:
        if not local_torch:
            raise ImportError("local torch missing")
        import torch
        if not torch.cuda.is_available():
            raise ImportError("CUDA unavailable")
        return
    except Exception:
        for name in list(sys.modules):
            if name == "torch" or name.startswith("torch."):
                sys.modules.pop(name, None)
        status("正在把 NVIDIA CUDA 版 PyTorch 安装到所选目录…")
        errors = []
        for idx in ("https://download.pytorch.org/whl/cu128", "https://download.pytorch.org/whl/cu126"):
            try:
                run_pip(site, ["torch", "--index-url", idx])
                import importlib
                torch = importlib.import_module("torch")
                if torch.cuda.is_available():
                    return
                errors.append(idx + ": CUDA 不可用")
            except Exception as e:
                errors.append(idx + ": " + str(e))
                for name in list(sys.modules):
                    if name == "torch" or name.startswith("torch."):
                        sys.modules.pop(name, None)
        raise RuntimeError("无法启用 NVIDIA CUDA。\n" + "\n".join(errors[-2:]))


def nvidia_ok():
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        p = subprocess.run(["nvidia-smi", "-L"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=8, creationflags=creationflags)
        return p.returncode == 0 and "NVIDIA" in p.stdout.upper()
    except Exception:
        return False


def enum_candidate_windows():
    out = []
    @EnumWindowsProc
    def cb(hwnd, lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value
            low = title.lower()
            if any(x in low for x in ("ldplayer", "雷电", "王者荣耀", "honor of kings")):
                r = RECT()
                if user32.GetWindowRect(hwnd, ctypes.byref(r)):
                    area = max(0, r.right - r.left) * max(0, r.bottom - r.top)
                    if area > 120000:
                        out.append((area, hwnd, title))
        except Exception:
            pass
        return True
    user32.EnumWindows(cb, 0)
    out.sort(reverse=True)
    return out


def find_player_window(timeout=0):
    end = time.time() + timeout
    while True:
        c = enum_candidate_windows()
        if c:
            return c[0][1]
        if time.time() >= end:
            return None
        time.sleep(0.5)


def client_box(hwnd):
    r = RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(r)):
        return None
    p = POINT(r.left, r.top)
    if not user32.ClientToScreen(hwnd, ctypes.byref(p)):
        return None
    w = r.right - r.left
    h = r.bottom - r.top
    if w < 320 or h < 240:
        return None
    return p.x, p.y, w, h


def target_foreground(hwnd):
    fg = user32.GetForegroundWindow()
    if not fg or not hwnd:
        return False
    try:
        return user32.GetAncestor(fg, GA_ROOT) == user32.GetAncestor(hwnd, GA_ROOT)
    except Exception:
        return fg == hwnd


def activate_window(hwnd):
    if not hwnd:
        return
    try:
        user32.ShowWindow(hwnd, SW_RESTORE)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        pass


def launch_player(exe):
    hwnd = find_player_window(0)
    creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    if not hwnd:
        subprocess.Popen([exe], cwd=os.path.dirname(exe), creationflags=creationflags)
        hwnd = find_player_window(45)
    if not hwnd:
        raise RuntimeError("未找到雷电模拟器窗口。")
    ldconsole = os.path.join(os.path.dirname(exe), "ldconsole.exe")
    if os.path.isfile(ldconsole):
        try:
            subprocess.Popen([ldconsole, "runapp", "--index", "0", "--packagename", PACKAGE], cwd=os.path.dirname(exe), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception:
            pass
    activate_window(hwnd)
    return hwnd


def send_inputs(items):
    if not items:
        return
    arr = (INPUT * len(items))(*items)
    sent = user32.SendInput(len(items), arr, ctypes.sizeof(INPUT))
    if sent != len(items):
        raise RuntimeError("Windows SendInput 失败。")


def key_input(vk, up=False):
    i = INPUT()
    i.type = INPUT_KEYBOARD
    i.ki = KEYBDINPUT(vk & 0xFFFF, 0, KEYEVENTF_KEYUP if up else 0, 0, MAGIC)
    return i


def abs_mouse_input(x, y, flags):
    vx = user32.GetSystemMetrics(SM_XVIRTUALSCREEN)
    vy = user32.GetSystemMetrics(SM_YVIRTUALSCREEN)
    vw = max(1, user32.GetSystemMetrics(SM_CXVIRTUALSCREEN) - 1)
    vh = max(1, user32.GetSystemMetrics(SM_CYVIRTUALSCREEN) - 1)
    nx = int((x - vx) * 65535 / vw)
    ny = int((y - vy) * 65535 / vh)
    i = INPUT()
    i.type = INPUT_MOUSE
    i.mi = MOUSEINPUT(nx, ny, 0, MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK | flags, 0, MAGIC)
    return i


class InputMonitor:
    def __init__(self, is_ai_active, on_physical_during_ai, get_target_hwnd):
        self.is_ai_active = is_ai_active
        self.on_physical_during_ai = on_physical_during_ai
        self.get_target_hwnd = get_target_hwnd
        self.events = queue.Queue(maxsize=4096)
        self.stop_evt = threading.Event()
        self.thread_id = 0
        self.thread = None
        self._kbd_cb = None
        self._mouse_cb = None
        self._mouse_down = 0
        self._last_move = 0.0

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, name="InputMonitor", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_evt.set()
        if self.thread_id:
            user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)

    def _physical(self):
        if self.is_ai_active():
            self.on_physical_during_ai()
            return False
        hwnd = self.get_target_hwnd()
        return bool(hwnd and target_foreground(hwnd))

    def _put(self, item):
        try:
            self.events.put_nowait(item)
        except queue.Full:
            try:
                self.events.get_nowait()
            except Exception:
                pass
            try:
                self.events.put_nowait(item)
            except Exception:
                pass

    def _run(self):
        self.thread_id = kernel32.GetCurrentThreadId()

        @LowLevelProc
        def keyboard_proc(code, wparam, lparam):
            try:
                if code == HC_ACTION:
                    s = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    injected = bool(s.flags & LLKHF_INJECTED) or int(s.dwExtraInfo) == MAGIC
                    if not injected and self._physical():
                        if wparam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                            self._put((time.time(), TYPE_KEY_DOWN, int(s.vkCode), 0.0, 0.0))
                        elif wparam in (WM_KEYUP, WM_SYSKEYUP):
                            self._put((time.time(), TYPE_KEY_UP, int(s.vkCode), 0.0, 0.0))
            except Exception:
                pass
            return user32.CallNextHookEx(None, code, wparam, lparam)

        @LowLevelProc
        def mouse_proc(code, wparam, lparam):
            try:
                if code == HC_ACTION:
                    s = ctypes.cast(lparam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                    injected = bool(s.flags & LLMHF_INJECTED) or int(s.dwExtraInfo) == MAGIC
                    if not injected:
                        ai = self.is_ai_active()
                        allow_record = self._physical()
                        if ai:
                            return user32.CallNextHookEx(None, code, wparam, lparam)
                        t = time.time()
                        typ = None
                        if wparam == WM_LBUTTONDOWN:
                            self._mouse_down |= 1
                            typ = TYPE_MOUSE_DOWN_L
                        elif wparam == WM_LBUTTONUP:
                            self._mouse_down &= ~1
                            typ = TYPE_MOUSE_UP_L
                        elif wparam == WM_RBUTTONDOWN:
                            self._mouse_down |= 2
                            typ = TYPE_MOUSE_DOWN_R
                        elif wparam == WM_RBUTTONUP:
                            self._mouse_down &= ~2
                            typ = TYPE_MOUSE_UP_R
                        elif wparam == WM_MOUSEMOVE and self._mouse_down and t - self._last_move >= 0.075:
                            self._last_move = t
                            typ = TYPE_MOUSE_MOVE
                        if allow_record and typ is not None:
                            hwnd = self.get_target_hwnd()
                            b = client_box(hwnd) if hwnd else None
                            if b:
                                l, top, w, h = b
                                x = (s.pt.x - l) / max(1, w)
                                y = (s.pt.y - top) / max(1, h)
                                if -0.05 <= x <= 1.05 and -0.05 <= y <= 1.05:
                                    self._put((t, typ, 0, min(1.0, max(0.0, x)), min(1.0, max(0.0, y))))
            except Exception:
                pass
            return user32.CallNextHookEx(None, code, wparam, lparam)

        self._kbd_cb = keyboard_proc
        self._mouse_cb = mouse_proc
        hk = user32.SetWindowsHookExW(WH_KEYBOARD_LL, keyboard_proc, kernel32.GetModuleHandleW(None), 0)
        hm = user32.SetWindowsHookExW(WH_MOUSE_LL, mouse_proc, kernel32.GetModuleHandleW(None), 0)
        if not hk or not hm:
            if hk:
                user32.UnhookWindowsHookEx(hk)
            if hm:
                user32.UnhookWindowsHookEx(hm)
            return
        msg = wintypes.MSG()
        while not self.stop_evt.is_set() and user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(hk)
        user32.UnhookWindowsHookEx(hm)


class FrameSource:
    def __init__(self, get_hwnd):
        import mss
        import numpy as np
        self.mss_mod = mss
        self.np = np
        self.get_hwnd = get_hwnd
        self.local = threading.local()

    def _grabber(self):
        g = getattr(self.local, "grabber", None)
        if g is None:
            g = self.mss_mod.mss()
            self.local.grabber = g
        return g

    def gray(self):
        hwnd = self.get_hwnd()
        if not hwnd:
            return None
        b = client_box(hwnd)
        if not b:
            return None
        l, t, w, h = b
        raw = self._grabber().grab({"left": l, "top": t, "width": w, "height": h})
        a = self.np.asarray(raw, dtype=self.np.uint8)
        rgb = a[:, :, :3]
        gray = ((rgb[:, :, 0].astype(self.np.uint16) * 29 + rgb[:, :, 1].astype(self.np.uint16) * 150 + rgb[:, :, 2].astype(self.np.uint16) * 77) >> 8).astype(self.np.uint8)
        ys = self.np.linspace(0, gray.shape[0] - 1, FRAME_H).astype(self.np.int32)
        xs = self.np.linspace(0, gray.shape[1] - 1, FRAME_W).astype(self.np.int32)
        return gray[ys][:, xs]


class FrameStacker:
    def __init__(self, source):
        self.source = source
        self.frames = []

    def get(self):
        f = self.source.gray()
        if f is None:
            return None
        self.frames.append(f)
        if len(self.frames) > FRAME_STACK:
            self.frames.pop(0)
        while len(self.frames) < FRAME_STACK:
            self.frames.insert(0, self.frames[0].copy())
        return self.source.np.stack(self.frames, axis=0)


class Dataset:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, timeout=30)
        with self.lock:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("CREATE TABLE IF NOT EXISTS samples(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, typ INTEGER NOT NULL, key INTEGER NOT NULL, x REAL NOT NULL, y REAL NOT NULL, frame BLOB NOT NULL)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_samples_ts ON samples(ts)")
            self.conn.commit()

    def add(self, frame, typ, key, x, y):
        import zlib
        blob = zlib.compress(frame.tobytes(), 1)
        with self.lock:
            self.conn.execute("INSERT INTO samples(ts,typ,key,x,y,frame) VALUES(?,?,?,?,?,?)", (time.time(), typ, key, x, y, blob))
            self.conn.commit()
            c = self.conn.execute("SELECT COUNT(*) FROM samples").fetchone()[0]
            if c > MAX_SAMPLES:
                self.conn.execute("DELETE FROM samples WHERE id IN (SELECT id FROM samples ORDER BY id ASC LIMIT 2000)")
                self.conn.commit()

    def count(self):
        with self.lock:
            return int(self.conn.execute("SELECT COUNT(*) FROM samples").fetchone()[0])

    def batch(self, n):
        import zlib
        import numpy as np
        with self.lock:
            rows = self.conn.execute("SELECT typ,key,x,y,frame FROM samples ORDER BY RANDOM() LIMIT ?", (n,)).fetchall()
        out = []
        expected = FRAME_STACK * FRAME_H * FRAME_W
        for typ, key, x, y, blob in rows:
            raw = zlib.decompress(blob)
            a = np.frombuffer(raw, dtype=np.uint8)
            if a.size == expected:
                out.append((a.reshape(FRAME_STACK, FRAME_H, FRAME_W), typ, key, x, y))
        return out


class ModelEngine:
    def __init__(self, paths, dataset, ai_active, status):
        import torch
        self.torch = torch
        self.nn = torch.nn
        self.paths = paths
        self.dataset = dataset
        self.ai_active = ai_active
        self.status = status
        self.device = torch.device("cuda")
        self.model_path = os.path.join(paths["models"], "policy.pt")
        self.lock = threading.RLock()
        self.stop_evt = threading.Event()
        self.model = self._build().to(self.device)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=2e-4, weight_decay=1e-4)
        self.steps = 0
        self._load()
        self.thread = threading.Thread(target=self._train_loop, name="Trainer", daemon=True)
        self.thread.start()

    def _build(self):
        nn = self.nn
        class Net(nn.Module):
            def __init__(self):
                super().__init__()
                self.body = nn.Sequential(
                    nn.Conv2d(FRAME_STACK, 24, 5, 2, 2), nn.SiLU(),
                    nn.Conv2d(24, 48, 3, 2, 1), nn.SiLU(),
                    nn.Conv2d(48, 80, 3, 2, 1), nn.SiLU(),
                    nn.Conv2d(80, 96, 3, 2, 1), nn.SiLU(),
                    nn.AdaptiveAvgPool2d((3, 5)), nn.Flatten(),
                    nn.Linear(96 * 3 * 5, 256), nn.SiLU(), nn.Dropout(0.05)
                )
                self.type_head = nn.Linear(256, TYPE_COUNT)
                self.key_head = nn.Linear(256, 256)
                self.xy_head = nn.Sequential(nn.Linear(256, 2), nn.Sigmoid())
            def forward(self, x):
                z = self.body(x)
                return self.type_head(z), self.key_head(z), self.xy_head(z)
        return Net()

    def _load(self):
        if not os.path.isfile(self.model_path):
            return
        try:
            d = self.torch.load(self.model_path, map_location=self.device, weights_only=False)
            self.model.load_state_dict(d["model"])
            if "optimizer" in d:
                self.optimizer.load_state_dict(d["optimizer"])
            self.steps = int(d.get("steps", 0))
        except Exception:
            pass

    def _save(self):
        tmp = self.model_path + ".tmp"
        d = {"model": self.model.state_dict(), "optimizer": self.optimizer.state_dict(), "steps": self.steps}
        self.torch.save(d, tmp)
        os.replace(tmp, self.model_path)

    def stop(self):
        self.stop_evt.set()
        try:
            with self.lock:
                self._save()
        except Exception:
            pass

    def predict(self, frame):
        torch = self.torch
        with self.lock, torch.no_grad():
            self.model.eval()
            x = torch.from_numpy(frame).to(self.device, non_blocking=True).float().unsqueeze(0) / 255.0
            typ, key, xy = self.model(x)
            pt = torch.softmax(typ, dim=1)[0]
            pk = torch.softmax(key, dim=1)[0]
            t = int(torch.argmax(pt).item())
            k = int(torch.argmax(pk).item())
            return t, float(pt[t].item()), k, float(pk[k].item()), float(xy[0, 0].item()), float(xy[0, 1].item())

    def _train_loop(self):
        torch = self.torch
        idle_note = 0.0
        while not self.stop_evt.is_set():
            try:
                if self.ai_active() or self.dataset.count() < 32:
                    time.sleep(0.35)
                    continue
                batch = self.dataset.batch(64)
                if len(batch) < 16:
                    time.sleep(0.5)
                    continue
                frames = torch.from_numpy(__import__("numpy").stack([b[0] for b in batch])).to(self.device).float() / 255.0
                types = torch.tensor([b[1] for b in batch], dtype=torch.long, device=self.device)
                keys = torch.tensor([b[2] for b in batch], dtype=torch.long, device=self.device)
                xy = torch.tensor([[b[3], b[4]] for b in batch], dtype=torch.float32, device=self.device)
                with self.lock:
                    self.model.train()
                    self.optimizer.zero_grad(set_to_none=True)
                    type_logits, key_logits, xy_pred = self.model(frames)
                    weights = torch.tensor([0.35, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.8], dtype=torch.float32, device=self.device)
                    loss = torch.nn.functional.cross_entropy(type_logits, types, weight=weights)
                    km = (types == TYPE_KEY_DOWN) | (types == TYPE_KEY_UP)
                    if km.any():
                        loss = loss + 0.7 * torch.nn.functional.cross_entropy(key_logits[km], keys[km])
                    mm = types >= TYPE_MOUSE_DOWN_L
                    if mm.any():
                        loss = loss + 2.0 * torch.nn.functional.smooth_l1_loss(xy_pred[mm], xy[mm])
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 2.0)
                    self.optimizer.step()
                    self.steps += 1
                    if self.steps % 100 == 0:
                        self._save()
                if time.time() - idle_note > 5:
                    idle_note = time.time()
                    self.status("正在从用户操作学习 · 样本 %d · 训练 %d" % (self.dataset.count(), self.steps))
                time.sleep(0.03)
            except Exception:
                time.sleep(1.0)


class Controller:
    def __init__(self, home, player, status, on_ai_end):
        self.home = home
        self.player = player
        self.status = status
        self.on_ai_end = on_ai_end
        self.paths = configure_storage(home)
        self.hwnd = None
        self.ai_evt = threading.Event()
        self.stop_evt = threading.Event()
        self.quit_evt = threading.Event()
        self._end_lock = threading.Lock()
        self._ending = False
        self.keys_down = set()
        self.mouse_down = set()
        self.monitor = InputMonitor(self.ai_evt.is_set, self.stop_ai_from_user, lambda: self.hwnd)
        self.source = None
        self.dataset = None
        self.engine = None
        self.rec_thread = None
        self.ai_thread = None

    def initialize(self):
        if not nvidia_ok():
            raise RuntimeError("未检测到可用的 NVIDIA 显卡/驱动。")
        ensure_dependencies(self.paths, self.status)
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("PyTorch 未检测到 CUDA。")
        self.status("正在启动雷电模拟器…")
        self.hwnd = launch_player(self.player)
        self.source = FrameSource(lambda: self.hwnd)
        self.dataset = Dataset(os.path.join(self.paths["data"], "experience.sqlite3"))
        self.engine = ModelEngine(self.paths, self.dataset, self.ai_evt.is_set, self.status)
        self.monitor.start()
        self.rec_thread = threading.Thread(target=self._record_loop, name="Recorder", daemon=True)
        self.rec_thread.start()
        self.status("就绪 · 已学习样本 %d" % self.dataset.count())

    def close(self):
        self.quit_evt.set()
        self.stop_ai("程序退出", notify=False)
        try:
            self.monitor.stop()
        except Exception:
            pass
        try:
            if self.engine:
                self.engine.stop()
        except Exception:
            pass

    def _record_loop(self):
        stacker = FrameStacker(self.source)
        last_event = time.time()
        last_idle = 0.0
        while not self.quit_evt.is_set():
            try:
                if self.ai_evt.is_set() or not self.hwnd or not target_foreground(self.hwnd):
                    time.sleep(0.1)
                    continue
                frame = stacker.get()
                if frame is None:
                    time.sleep(0.1)
                    continue
                drained = 0
                while drained < 24:
                    try:
                        ev = self.monitor.events.get_nowait()
                    except queue.Empty:
                        break
                    _, typ, key, x, y = ev
                    self.dataset.add(frame, typ, key, x, y)
                    last_event = time.time()
                    drained += 1
                now = time.time()
                if drained == 0 and now - last_event > 0.55 and now - last_idle > 0.85:
                    last_idle = now
                    self.dataset.add(frame, TYPE_IDLE, 0, 0.0, 0.0)
                time.sleep(0.075)
            except Exception:
                time.sleep(0.2)

    def start_ai(self):
        if self.ai_evt.is_set():
            return
        if not self.hwnd or not user32.IsWindow(self.hwnd):
            self.hwnd = launch_player(self.player)
        activate_window(self.hwnd)
        self.stop_evt.clear()
        self._ending = False
        self.ai_evt.set()
        self.ai_thread = threading.Thread(target=self._ai_loop, name="AIPlayer", daemon=True)
        self.ai_thread.start()

    def stop_ai_from_user(self):
        if self.ai_evt.is_set() and not self.stop_evt.is_set():
            self.stop_evt.set()
            threading.Thread(target=self.stop_ai, args=("检测到用户键鼠操作",), name="UserStop", daemon=True).start()

    def stop_ai(self, reason="AI 已停止", notify=True):
        with self._end_lock:
            if self._ending:
                return
            self._ending = True
        self.stop_evt.set()
        self.ai_evt.clear()
        try:
            self._release_all()
        except Exception:
            pass
        if notify:
            self.on_ai_end(reason)
        with self._end_lock:
            self._ending = False

    def _release_all(self):
        items = []
        for k in list(self.keys_down):
            items.append(key_input(k, True))
        if "L" in self.mouse_down:
            items.append(abs_mouse_input(0, 0, MOUSEEVENTF_LEFTUP))
        if "R" in self.mouse_down:
            items.append(abs_mouse_input(0, 0, MOUSEEVENTF_RIGHTUP))
        self.keys_down.clear()
        self.mouse_down.clear()
        if items:
            send_inputs(items)

    def _execute(self, typ, key, x, y):
        b = client_box(self.hwnd)
        if not b:
            raise RuntimeError("雷电模拟器窗口不可用。")
        l, t, w, h = b
        sx = l + int(min(1.0, max(0.0, x)) * max(1, w - 1))
        sy = t + int(min(1.0, max(0.0, y)) * max(1, h - 1))
        if typ == TYPE_KEY_DOWN:
            if key not in self.keys_down:
                send_inputs([key_input(key, False)])
                self.keys_down.add(key)
        elif typ == TYPE_KEY_UP:
            send_inputs([key_input(key, True)])
            self.keys_down.discard(key)
        elif typ == TYPE_MOUSE_DOWN_L:
            send_inputs([abs_mouse_input(sx, sy, MOUSEEVENTF_MOVE), abs_mouse_input(sx, sy, MOUSEEVENTF_LEFTDOWN)])
            self.mouse_down.add("L")
        elif typ == TYPE_MOUSE_UP_L:
            send_inputs([abs_mouse_input(sx, sy, MOUSEEVENTF_MOVE), abs_mouse_input(sx, sy, MOUSEEVENTF_LEFTUP)])
            self.mouse_down.discard("L")
        elif typ == TYPE_MOUSE_DOWN_R:
            send_inputs([abs_mouse_input(sx, sy, MOUSEEVENTF_MOVE), abs_mouse_input(sx, sy, MOUSEEVENTF_RIGHTDOWN)])
            self.mouse_down.add("R")
        elif typ == TYPE_MOUSE_UP_R:
            send_inputs([abs_mouse_input(sx, sy, MOUSEEVENTF_MOVE), abs_mouse_input(sx, sy, MOUSEEVENTF_RIGHTUP)])
            self.mouse_down.discard("R")
        elif typ == TYPE_MOUSE_MOVE:
            send_inputs([abs_mouse_input(sx, sy, MOUSEEVENTF_MOVE)])

    def _bootstrap_action(self):
        r = random.random()
        movement = [ord("W"), ord("A"), ord("S"), ord("D")]
        combat = [ord("J"), ord("K"), ord("L"), ord("I"), ord("O"), ord("Q"), ord("E"), ord("R"), ord("G"), ord("3")]
        if r < 0.58:
            k = random.choice(movement)
            send_inputs([key_input(k, False)])
            self.keys_down.add(k)
            time.sleep(random.uniform(0.12, 0.42))
            send_inputs([key_input(k, True)])
            self.keys_down.discard(k)
        elif r < 0.88:
            k = random.choice(combat)
            send_inputs([key_input(k, False), key_input(k, True)])
        else:
            time.sleep(random.uniform(0.15, 0.45))

    def _ai_loop(self):
        stacker = FrameStacker(self.source)
        try:
            low_data_note = 0.0
            while self.ai_evt.is_set() and not self.stop_evt.is_set() and not self.quit_evt.is_set():
                if not user32.IsWindow(self.hwnd):
                    raise RuntimeError("雷电模拟器已关闭。")
                if not target_foreground(self.hwnd):
                    raise RuntimeError("雷电模拟器失去前台焦点。")
                count = self.dataset.count()
                if count < MIN_SAMPLES:
                    if time.time() - low_data_note > 3:
                        low_data_note = time.time()
                        self.status("AI 正在探索并等待更多用户示范 · %d/%d" % (count, MIN_SAMPLES))
                    self._bootstrap_action()
                    time.sleep(0.08)
                    continue
                frame = stacker.get()
                if frame is None:
                    raise RuntimeError("无法采集雷电模拟器画面。")
                typ, conf, key, keyconf, x, y = self.engine.predict(frame)
                if typ == TYPE_IDLE:
                    time.sleep(0.08)
                    continue
                threshold = 0.48 if self.engine.steps > 500 else 0.58
                if conf < threshold:
                    time.sleep(0.06)
                    continue
                if typ in (TYPE_KEY_DOWN, TYPE_KEY_UP) and keyconf < 0.10:
                    time.sleep(0.05)
                    continue
                self._execute(typ, key, x, y)
                time.sleep(0.055)
        except Exception as e:
            self.status("错误：" + str(e))
            self.stop_ai("发生错误：" + str(e))
            return
        if self.ai_evt.is_set():
            self.stop_ai("AI 已停止")


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(APP)
        self.root.geometry("640x280")
        self.root.minsize(600, 260)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.home_var = tk.StringVar(value=DEFAULT_HOME)
        self.player_var = tk.StringVar(value=DEFAULT_PLAYER)
        self.status_var = tk.StringVar(value="请选择运行目录和雷电模拟器路径。")
        self.controller = None
        self.busy = False
        self.ui_queue = queue.Queue()
        self._build()
        self.root.after(30, self._poll_ui)

    def _build(self):
        f = tk.Frame(self.root, padx=18, pady=18)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="运行目录（必须为非系统盘）").grid(row=0, column=0, sticky="w")
        tk.Entry(f, textvariable=self.home_var).grid(row=1, column=0, sticky="ew", padx=(0, 8), pady=(4, 14))
        tk.Button(f, text="选择", width=9, command=self.choose_home).grid(row=1, column=1, pady=(4, 14))
        tk.Label(f, text="雷电模拟器 dnplayer.exe").grid(row=2, column=0, sticky="w")
        tk.Entry(f, textvariable=self.player_var).grid(row=3, column=0, sticky="ew", padx=(0, 8), pady=(4, 16))
        tk.Button(f, text="选择", width=9, command=self.choose_player).grid(row=3, column=1, pady=(4, 16))
        self.ai_btn = tk.Button(f, text="AI", height=2, command=self.ai_clicked)
        self.ai_btn.grid(row=4, column=0, columnspan=2, sticky="ew")
        tk.Label(f, textvariable=self.status_var, anchor="w", justify="left", wraplength=590).grid(row=5, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        f.columnconfigure(0, weight=1)

    def status(self, text):
        try:
            self.ui_queue.put_nowait(("status", text))
        except Exception:
            pass

    def _poll_ui(self):
        try:
            for _ in range(64):
                try:
                    kind, value = self.ui_queue.get_nowait()
                except queue.Empty:
                    break
                if kind == "status":
                    self.status_var.set(value)
                elif kind == "error":
                    messagebox.showerror(APP, value)
                elif kind == "fade":
                    self.fade_out()
                elif kind == "ai_end":
                    self._show_after_ai(value)
                elif kind == "unlock":
                    self._unlock()
        finally:
            try:
                self.root.after(30, self._poll_ui)
            except Exception:
                pass

    def choose_home(self):
        initial = self.home_var.get()
        base = initial if os.path.isdir(initial) else (os.path.splitdrive(initial)[0] + "\\" if os.path.splitdrive(initial)[0] else "D:\\")
        p = filedialog.askdirectory(title="选择非系统盘运行目录", initialdir=base, mustexist=False)
        if p:
            self.home_var.set(p)

    def choose_player(self):
        initial = self.player_var.get()
        p = filedialog.askopenfilename(title="选择雷电模拟器 dnplayer.exe", initialdir=os.path.dirname(initial) if os.path.isdir(os.path.dirname(initial)) else None, initialfile=os.path.basename(initial), filetypes=[("dnplayer.exe", "dnplayer.exe"), ("EXE", "*.exe")])
        if p:
            self.player_var.set(p)

    def ai_clicked(self):
        if self.busy:
            return
        self.busy = True
        self.ai_btn.config(state="disabled")
        threading.Thread(target=self._prepare_and_start, name="Starter", daemon=True).start()

    def _prepare_and_start(self):
        try:
            home = ensure_non_system_folder(self.home_var.get())
            player = norm_path(self.player_var.get())
            if not os.path.isfile(player) or os.path.basename(player).lower() != "dnplayer.exe":
                raise RuntimeError("请选择有效的雷电模拟器 dnplayer.exe。")
            if self.controller is None or self.controller.home != home or self.controller.player != player:
                if self.controller:
                    self.controller.close()
                self.controller = Controller(home, player, self.status, self.ai_ended)
                self.controller.initialize()
            self.status("3 秒后 AI 接管；任何真实键鼠操作都会立即停止 AI。")
            self.ui_queue.put(("fade", None))
        except Exception as e:
            self.status("错误：" + str(e))
            self.ui_queue.put(("error", str(e)))
            self.ui_queue.put(("unlock", None))

    def fade_out(self):
        start = time.time()
        def step():
            elapsed = time.time() - start
            if elapsed >= 3.0:
                try:
                    self.root.attributes("-alpha", 0.0)
                    self.root.withdraw()
                except Exception:
                    pass
                try:
                    self.controller.start_ai()
                    self.status("AI 正在玩王者荣耀")
                except Exception as e:
                    self.ai_ended("发生错误：" + str(e))
                return
            a = max(0.0, 1.0 - elapsed / 3.0)
            try:
                self.root.attributes("-alpha", a)
            except Exception:
                pass
            self.root.after(30, step)
        step()

    def ai_ended(self, reason):
        try:
            self.ui_queue.put_nowait(("ai_end", reason))
        except Exception:
            pass

    def _show_after_ai(self, reason):
        try:
            self.root.deiconify()
            self.root.attributes("-alpha", 1.0)
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        self.status(reason)
        self._unlock()

    def _unlock(self):
        self.busy = False
        try:
            self.ai_btn.config(state="normal")
        except Exception:
            pass

    def close(self):
        try:
            if self.controller:
                self.controller.close()
        finally:
            self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    try:
        App().run()
    except Exception:
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(APP, traceback.format_exc())
        except Exception:
            pass
        raise
